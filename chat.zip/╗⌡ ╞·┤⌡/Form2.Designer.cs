﻿
namespace chat
{
    partial class join_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.phone_textBox = new System.Windows.Forms.TextBox();
            this.phone_label = new System.Windows.Forms.Label();
            this.pwcheck_textBox = new System.Windows.Forms.TextBox();
            this.pwcheck_label = new System.Windows.Forms.Label();
            this.ducheck_button = new System.Windows.Forms.Button();
            this.pw_textBox = new System.Windows.Forms.TextBox();
            this.id_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.name_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pwcheck_button = new System.Windows.Forms.Button();
            this.id_label = new System.Windows.Forms.Label();
            this.pw_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.join_button = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // phone_textBox
            // 
            this.phone_textBox.BackColor = System.Drawing.SystemColors.MenuBar;
            this.phone_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phone_textBox.Location = new System.Drawing.Point(3, 8);
            this.phone_textBox.Multiline = true;
            this.phone_textBox.Name = "phone_textBox";
            this.phone_textBox.Size = new System.Drawing.Size(117, 21);
            this.phone_textBox.TabIndex = 25;
            // 
            // phone_label
            // 
            this.phone_label.AutoSize = true;
            this.phone_label.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.phone_label.Location = new System.Drawing.Point(39, 321);
            this.phone_label.Name = "phone_label";
            this.phone_label.Size = new System.Drawing.Size(47, 17);
            this.phone_label.TabIndex = 23;
            this.phone_label.Text = "연락처";
            // 
            // pwcheck_textBox
            // 
            this.pwcheck_textBox.BackColor = System.Drawing.SystemColors.MenuBar;
            this.pwcheck_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pwcheck_textBox.Location = new System.Drawing.Point(4, 7);
            this.pwcheck_textBox.Multiline = true;
            this.pwcheck_textBox.Name = "pwcheck_textBox";
            this.pwcheck_textBox.PasswordChar = '*';
            this.pwcheck_textBox.Size = new System.Drawing.Size(116, 22);
            this.pwcheck_textBox.TabIndex = 21;
            // 
            // pwcheck_label
            // 
            this.pwcheck_label.AutoSize = true;
            this.pwcheck_label.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pwcheck_label.Location = new System.Drawing.Point(33, 229);
            this.pwcheck_label.Name = "pwcheck_label";
            this.pwcheck_label.Size = new System.Drawing.Size(53, 17);
            this.pwcheck_label.TabIndex = 20;
            this.pwcheck_label.Text = "PW확인";
            // 
            // ducheck_button
            // 
            this.ducheck_button.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.ducheck_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ducheck_button.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ducheck_button.Location = new System.Drawing.Point(240, 141);
            this.ducheck_button.Name = "ducheck_button";
            this.ducheck_button.Size = new System.Drawing.Size(65, 25);
            this.ducheck_button.TabIndex = 19;
            this.ducheck_button.Text = "중복확인";
            this.ducheck_button.UseVisualStyleBackColor = true;
            this.ducheck_button.Click += new System.EventHandler(this.ducheck_button_Click);
            // 
            // pw_textBox
            // 
            this.pw_textBox.BackColor = System.Drawing.SystemColors.MenuBar;
            this.pw_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pw_textBox.HideSelection = false;
            this.pw_textBox.Location = new System.Drawing.Point(3, 6);
            this.pw_textBox.Multiline = true;
            this.pw_textBox.Name = "pw_textBox";
            this.pw_textBox.PasswordChar = '*';
            this.pw_textBox.Size = new System.Drawing.Size(117, 21);
            this.pw_textBox.TabIndex = 18;
            // 
            // id_textBox
            // 
            this.id_textBox.BackColor = System.Drawing.SystemColors.MenuBar;
            this.id_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.id_textBox.Location = new System.Drawing.Point(4, 8);
            this.id_textBox.Multiline = true;
            this.id_textBox.Name = "id_textBox";
            this.id_textBox.Size = new System.Drawing.Size(110, 20);
            this.id_textBox.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(68, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 21);
            this.label1.TabIndex = 14;
            this.label1.Text = "회원가입";
            // 
            // name_textBox
            // 
            this.name_textBox.BackColor = System.Drawing.SystemColors.MenuBar;
            this.name_textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.name_textBox.Location = new System.Drawing.Point(3, 8);
            this.name_textBox.Multiline = true;
            this.name_textBox.Name = "name_textBox";
            this.name_textBox.Size = new System.Drawing.Size(117, 22);
            this.name_textBox.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(52, 274);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "이름";
            // 
            // pwcheck_button
            // 
            this.pwcheck_button.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.pwcheck_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pwcheck_button.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pwcheck_button.Location = new System.Drawing.Point(240, 227);
            this.pwcheck_button.Name = "pwcheck_button";
            this.pwcheck_button.Size = new System.Drawing.Size(65, 25);
            this.pwcheck_button.TabIndex = 30;
            this.pwcheck_button.Text = "PW 확인";
            this.pwcheck_button.UseVisualStyleBackColor = true;
            this.pwcheck_button.Click += new System.EventHandler(this.pwcheck_button_Click);
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.id_label.Location = new System.Drawing.Point(65, 144);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(21, 17);
            this.id_label.TabIndex = 15;
            this.id_label.Text = "ID";
            // 
            // pw_label
            // 
            this.pw_label.AutoSize = true;
            this.pw_label.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pw_label.Location = new System.Drawing.Point(59, 187);
            this.pw_label.Name = "pw_label";
            this.pw_label.Size = new System.Drawing.Size(27, 17);
            this.pw_label.TabIndex = 16;
            this.pw_label.Text = "PW";
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(17, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(300, 2);
            this.label3.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(17, 395);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(300, 2);
            this.label4.TabIndex = 32;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel1.Controls.Add(this.id_textBox);
            this.panel1.Location = new System.Drawing.Point(104, 137);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(120, 30);
            this.panel1.TabIndex = 34;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel2.Controls.Add(this.pw_textBox);
            this.panel2.Location = new System.Drawing.Point(104, 181);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(120, 30);
            this.panel2.TabIndex = 35;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel3.Controls.Add(this.pwcheck_textBox);
            this.panel3.Location = new System.Drawing.Point(104, 224);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(120, 30);
            this.panel3.TabIndex = 36;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel4.Controls.Add(this.name_textBox);
            this.panel4.Location = new System.Drawing.Point(104, 269);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(120, 30);
            this.panel4.TabIndex = 37;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel5.Controls.Add(this.phone_textBox);
            this.panel5.Location = new System.Drawing.Point(104, 315);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(120, 30);
            this.panel5.TabIndex = 38;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::chat.Properties.Resources.톡이미지1;
            this.pictureBox1.Location = new System.Drawing.Point(21, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // join_button
            // 
            this.join_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.join_button.FlatAppearance.BorderColor = System.Drawing.SystemColors.Window;
            this.join_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.join_button.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.join_button.Image = global::chat.Properties.Resources.회원가입;
            this.join_button.Location = new System.Drawing.Point(81, 435);
            this.join_button.Name = "join_button";
            this.join_button.Size = new System.Drawing.Size(172, 35);
            this.join_button.TabIndex = 27;
            this.join_button.UseVisualStyleBackColor = true;
            this.join_button.Click += new System.EventHandler(this.join_button_Click);
            // 
            // join_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(334, 511);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pwcheck_button);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.join_button);
            this.Controls.Add(this.phone_label);
            this.Controls.Add(this.pwcheck_label);
            this.Controls.Add(this.ducheck_button);
            this.Controls.Add(this.pw_label);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "join_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.join_Form_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.join_Form_MouseMove);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button join_button;
        private System.Windows.Forms.TextBox phone_textBox;
        private System.Windows.Forms.Label phone_label;
        private System.Windows.Forms.TextBox pwcheck_textBox;
        private System.Windows.Forms.Label pwcheck_label;
        private System.Windows.Forms.Button ducheck_button;
        private System.Windows.Forms.TextBox pw_textBox;
        private System.Windows.Forms.TextBox id_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox name_textBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button pwcheck_button;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.Label pw_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}